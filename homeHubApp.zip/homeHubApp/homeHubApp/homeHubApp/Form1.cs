﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homeHubApp
{
    public partial class Form1 : Form
    {
        private bool isCollapsed = true;

        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                pnlSupplier.Height += 10;
                if (pnlSupplier.Size == pnlSupplier.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                pnlSupplier.Height -= 10;
                if (pnlSupplier.Size == pnlSupplier.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                pnlCustomer.Height += 10;
                if (pnlCustomer.Size == pnlCustomer.MaximumSize)
                {
                    timer2.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                pnlCustomer.Height -= 10;
                if (pnlCustomer.Size == pnlCustomer.MinimumSize)
                {
                    timer2.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            frmCustomer frm = new frmCustomer();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.WindowState = FormWindowState.Maximized;
            pnlShow.Controls.Add(frm);
            frm.Show();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {

        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                pnlProduct.Height += 10;
                if (pnlProduct.Size == pnlProduct.MaximumSize)
                {
                    timer3.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                pnlProduct.Height -= 10;
                if (pnlProduct.Size == pnlProduct.MinimumSize)
                {
                    timer3.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void btnProduct_Click(object sender, EventArgs e)
        {
            timer3.Start(); ;
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                pnlOrder.Height += 10;
                if (pnlOrder.Size == pnlOrder.MaximumSize)
                {
                    timer4.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                pnlOrder.Height -= 10;
                if (pnlOrder.Size == pnlOrder.MinimumSize)
                {
                    timer4.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void btnOrder_Click_1(object sender, EventArgs e)
        {
            timer4.Start();
        }

        private void btnOrderDetail_Click(object sender, EventArgs e)
        {
            timer5.Start();
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                pnlOrderDetail.Height += 10;
                if (pnlOrderDetail.Size == pnlOrderDetail.MaximumSize)
                {
                    timer5.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                pnlOrderDetail.Height -= 10;
                if (pnlOrderDetail.Size == pnlOrderDetail.MinimumSize)
                {
                    timer5.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void btnCustomer_MouseEnter(object sender, EventArgs e)
        {
          
        }

        private void btnCustomer_MouseLeave(object sender, EventArgs e)
        {
            timer2.Start();
        }

        private void btnExitCustomer_Click(object sender, EventArgs e)
        {
            frmCustomer frm = new frmCustomer();
            frm.Close();
        }

        private void btnCustomer_MouseHover(object sender, EventArgs e)
        {
         //   timer2.Start();
        }

        private void pnlCustomer_MouseHover(object sender, EventArgs e)
        {
            timer2.Start();
        }
    }
}
