﻿namespace homeHubApp
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlCustomer = new System.Windows.Forms.Panel();
            this.btnExitCustomer = new System.Windows.Forms.Button();
            this.btnEditCustomer = new System.Windows.Forms.Button();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.btnCustomer = new System.Windows.Forms.Button();
            this.btnProduct = new System.Windows.Forms.Button();
            this.pnlSupplier = new System.Windows.Forms.Panel();
            this.btnSuppExit = new System.Windows.Forms.Button();
            this.btnSuppEdit = new System.Windows.Forms.Button();
            this.btnSuppAdd = new System.Windows.Forms.Button();
            this.btnSupplier = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnOrder = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            this.pnlCustomer.SuspendLayout();
            this.pnlSupplier.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.pnlCustomer);
            this.flowLayoutPanel1.Controls.Add(this.btnProduct);
            this.flowLayoutPanel1.Controls.Add(this.pnlSupplier);
            this.flowLayoutPanel1.Controls.Add(this.button1);
            this.flowLayoutPanel1.Controls.Add(this.btnOrder);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(162, 619);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // pnlCustomer
            // 
            this.pnlCustomer.Controls.Add(this.btnExitCustomer);
            this.pnlCustomer.Controls.Add(this.btnEditCustomer);
            this.pnlCustomer.Controls.Add(this.btnAddCustomer);
            this.pnlCustomer.Controls.Add(this.btnCustomer);
            this.pnlCustomer.Location = new System.Drawing.Point(3, 3);
            this.pnlCustomer.MaximumSize = new System.Drawing.Size(156, 166);
            this.pnlCustomer.MinimumSize = new System.Drawing.Size(156, 67);
            this.pnlCustomer.Name = "pnlCustomer";
            this.pnlCustomer.Size = new System.Drawing.Size(156, 67);
            this.pnlCustomer.TabIndex = 4;
            // 
            // btnExitCustomer
            // 
            this.btnExitCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(183)))), ((int)(((byte)(240)))));
            this.btnExitCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnExitCustomer.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnExitCustomer.FlatAppearance.BorderSize = 0;
            this.btnExitCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExitCustomer.Location = new System.Drawing.Point(0, 131);
            this.btnExitCustomer.Name = "btnExitCustomer";
            this.btnExitCustomer.Size = new System.Drawing.Size(156, 33);
            this.btnExitCustomer.TabIndex = 8;
            this.btnExitCustomer.Text = "Exit";
            this.btnExitCustomer.UseVisualStyleBackColor = false;
            // 
            // btnEditCustomer
            // 
            this.btnEditCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(183)))), ((int)(((byte)(240)))));
            this.btnEditCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnEditCustomer.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnEditCustomer.FlatAppearance.BorderSize = 0;
            this.btnEditCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEditCustomer.Location = new System.Drawing.Point(0, 98);
            this.btnEditCustomer.Name = "btnEditCustomer";
            this.btnEditCustomer.Size = new System.Drawing.Size(156, 33);
            this.btnEditCustomer.TabIndex = 7;
            this.btnEditCustomer.Text = "Edit";
            this.btnEditCustomer.UseVisualStyleBackColor = false;
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(183)))), ((int)(((byte)(240)))));
            this.btnAddCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAddCustomer.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAddCustomer.FlatAppearance.BorderSize = 0;
            this.btnAddCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddCustomer.Location = new System.Drawing.Point(0, 65);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(156, 33);
            this.btnAddCustomer.TabIndex = 6;
            this.btnAddCustomer.Text = "Add";
            this.btnAddCustomer.UseVisualStyleBackColor = false;
            // 
            // btnCustomer
            // 
            this.btnCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(183)))), ((int)(((byte)(220)))));
            this.btnCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCustomer.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCustomer.FlatAppearance.BorderSize = 0;
            this.btnCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustomer.Location = new System.Drawing.Point(0, 0);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(156, 65);
            this.btnCustomer.TabIndex = 1;
            this.btnCustomer.Text = "Customer";
            this.btnCustomer.UseVisualStyleBackColor = false;
            // 
            // btnProduct
            // 
            this.btnProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(183)))), ((int)(((byte)(220)))));
            this.btnProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnProduct.FlatAppearance.BorderSize = 0;
            this.btnProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProduct.Location = new System.Drawing.Point(3, 76);
            this.btnProduct.Name = "btnProduct";
            this.btnProduct.Size = new System.Drawing.Size(155, 65);
            this.btnProduct.TabIndex = 5;
            this.btnProduct.Text = "Product";
            this.btnProduct.UseVisualStyleBackColor = false;
            // 
            // pnlSupplier
            // 
            this.pnlSupplier.Controls.Add(this.btnSuppExit);
            this.pnlSupplier.Controls.Add(this.btnSuppEdit);
            this.pnlSupplier.Controls.Add(this.btnSuppAdd);
            this.pnlSupplier.Controls.Add(this.btnSupplier);
            this.pnlSupplier.Location = new System.Drawing.Point(3, 147);
            this.pnlSupplier.MaximumSize = new System.Drawing.Size(156, 166);
            this.pnlSupplier.MinimumSize = new System.Drawing.Size(156, 67);
            this.pnlSupplier.Name = "pnlSupplier";
            this.pnlSupplier.Size = new System.Drawing.Size(156, 67);
            this.pnlSupplier.TabIndex = 6;
            // 
            // btnSuppExit
            // 
            this.btnSuppExit.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnSuppExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSuppExit.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSuppExit.FlatAppearance.BorderSize = 0;
            this.btnSuppExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuppExit.Location = new System.Drawing.Point(0, 131);
            this.btnSuppExit.Name = "btnSuppExit";
            this.btnSuppExit.Size = new System.Drawing.Size(156, 33);
            this.btnSuppExit.TabIndex = 8;
            this.btnSuppExit.Text = "Exit";
            this.btnSuppExit.UseVisualStyleBackColor = false;
            // 
            // btnSuppEdit
            // 
            this.btnSuppEdit.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnSuppEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSuppEdit.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSuppEdit.FlatAppearance.BorderSize = 0;
            this.btnSuppEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuppEdit.Location = new System.Drawing.Point(0, 98);
            this.btnSuppEdit.Name = "btnSuppEdit";
            this.btnSuppEdit.Size = new System.Drawing.Size(156, 33);
            this.btnSuppEdit.TabIndex = 7;
            this.btnSuppEdit.Text = "Edit";
            this.btnSuppEdit.UseVisualStyleBackColor = false;
            // 
            // btnSuppAdd
            // 
            this.btnSuppAdd.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnSuppAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSuppAdd.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSuppAdd.FlatAppearance.BorderSize = 0;
            this.btnSuppAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuppAdd.Location = new System.Drawing.Point(0, 65);
            this.btnSuppAdd.Name = "btnSuppAdd";
            this.btnSuppAdd.Size = new System.Drawing.Size(156, 33);
            this.btnSuppAdd.TabIndex = 6;
            this.btnSuppAdd.Text = "Add";
            this.btnSuppAdd.UseVisualStyleBackColor = false;
            // 
            // btnSupplier
            // 
            this.btnSupplier.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(183)))), ((int)(((byte)(220)))));
            this.btnSupplier.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSupplier.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSupplier.FlatAppearance.BorderSize = 0;
            this.btnSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSupplier.Location = new System.Drawing.Point(0, 0);
            this.btnSupplier.Name = "btnSupplier";
            this.btnSupplier.Size = new System.Drawing.Size(156, 65);
            this.btnSupplier.TabIndex = 4;
            this.btnSupplier.Text = "Supplier";
            this.btnSupplier.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(183)))), ((int)(((byte)(220)))));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(3, 220);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 65);
            this.button1.TabIndex = 8;
            this.button1.Text = "Order Detail";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // btnOrder
            // 
            this.btnOrder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(183)))), ((int)(((byte)(220)))));
            this.btnOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnOrder.FlatAppearance.BorderSize = 0;
            this.btnOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOrder.Location = new System.Drawing.Point(3, 291);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(155, 65);
            this.btnOrder.TabIndex = 7;
            this.btnOrder.Text = "Order";
            this.btnOrder.UseVisualStyleBackColor = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 770);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.pnlCustomer.ResumeLayout(false);
            this.pnlSupplier.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel pnlCustomer;
        private System.Windows.Forms.Button btnExitCustomer;
        private System.Windows.Forms.Button btnEditCustomer;
        private System.Windows.Forms.Button btnAddCustomer;
        private System.Windows.Forms.Button btnCustomer;
        private System.Windows.Forms.Button btnProduct;
        private System.Windows.Forms.Panel pnlSupplier;
        private System.Windows.Forms.Button btnSuppExit;
        private System.Windows.Forms.Button btnSuppEdit;
        private System.Windows.Forms.Button btnSuppAdd;
        private System.Windows.Forms.Button btnSupplier;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnOrder;
    }
}